
import paddle
import argparse
import os
import yaml
from src.networks import instantiate_network
from src.utils.dot_dict import DotDict
from src.utils.dot_dict import flatten_dict

def load_config(config_path):
    with open(config_path, "r") as f:
        config = yaml.load(f, Loader=yaml.Loader)
    config = flatten_dict(config)
    return DotDict(config)

def count_model_parameters(model):
    return sum(p.numel() for p in model.parameters() if not p.stop_gradient)

def analyze_model(config_path):
    config = load_config(config_path)
    model = instantiate_network(config)

    param_count = count_model_parameters(model)
    print(f"✅ 模型名称: {config.model}")
    print(f"📦 模型参数总数: {param_count / 1e6:.2f} M")

    try:
        import pynvml
        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        meminfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
        print(f"💾 显存占用（运行前）: {meminfo.used / 1024**3:.2f} GB")
    except Exception as e:
        print("⚠️ 无法获取显存信息，可能未在 GPU 上运行")

    # FLOPs 估算（粗略，仅供参考）
    try:
        from paddle.static import InputSpec
        input_spec = [InputSpec(shape=[1] + config.sdf_spatial_resolution, dtype='float32')]
        paddle.summary(model, input_spec=input_spec)
    except:
        print("⚠️ FLOPs 估算失败，可能缺少 InputSpec 或模型不支持")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, default="configs/UnetShapeNetCar.yaml")
    args = parser.parse_args()
    analyze_model(args.config)
