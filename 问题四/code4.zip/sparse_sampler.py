import paddle
import numpy as np

def apply_sparse_sampling(data_dict, ratio=1.0):
    """
    对输入数据进行稀疏采样
    :param data_dict: 原始输入数据（包含coords, target等）
    :param ratio: 保留比例（0~1之间）
    :return: 采样后的 data_dict
    """
    coords = data_dict['coords']
    target = data_dict['target']
    
    N = coords.shape[0]
    sampled_indices = np.random.choice(N, int(N * ratio), replace=False)

    data_dict['coords'] = paddle.to_tensor(coords[sampled_indices])
    data_dict['target'] = paddle.to_tensor(target[sampled_indices])
    return data_dict
