# Copyright (c) 2023 PaddlePaddle Authors. All Rights Reserved.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


# Code is heavily based on paper "Geometry-Informed Neural Operator for Large-Scale 3D PDEs", we use paddle to reproduce the results of the paper

from .regdgcnn import *
from .ConvUNet2 import UNet3DWithSamplePoints


# print the number of parameters
import operator
from functools import reduce
def count_params(model):
    c = 0
    for p in list(model.parameters()):
        c += reduce(operator.mul, list(p.shape + (2,) if p.is_complex() else p.shape))
    return c


def instantiate_network(config):
    if config.model == "UNet":
        model = UNet3DWithSamplePoints(
            in_channels=config.in_channels,  # xyz + sdf
            out_channels=config.out_channels,
            hidden_channels=config.hidden_channels,
            num_levels=config.num_levels,
            use_position_input=config.use_position_input,
        )
    elif config.model == "RegDGCNN":
        
        import paddle
        class My_RegDGCNN(paddle.nn.Layer):
            def __init__(self):
                super(My_RegDGCNN, self).__init__()
                self.model= RegDGCNN(input_keys=["vertices"],
                            label_keys=["cd_value"],
                            weight_keys=["weight_keys"],
                            args={'dropout':0.3,'k':2,'emb_dims':256})
        
            def forward(self, x, output_points):
                input = {"vertices":output_points}
                output = self.model(input)
                output['cd_value'] = output['cd_value'].squeeze(axis=1)
                return output['cd_value']
        
            def data_dict_to_input(self, data_dict):
                input_grid_features = data_dict['sdf'].unsqueeze(axis=1)
                output_points = data_dict['vertices']
                return input_grid_features, output_points
        
            @paddle.no_grad()
            def eval_dict(self, data_dict, loss_fn=None, decode_fn=None, **kwargs):
                input_grid_features, output_points = self.data_dict_to_input(data_dict)
                pred_var = self(input_grid_features, output_points)
                pred_var = decode_fn(pred_var)
                pred_var_key = None
                if 'pressure' in data_dict.keys():
                    pred_var = pred_var.squeeze(0)
                    pred_var_key = 'pressure'
                elif "velocity" in data_dict.keys():
                    pred_var = pred_var.squeeze(0)
                    pred_var_key = 'velocity'
                elif "cd" in data_dict.keys():
                    # pred_var = paddle.mean(pred_var)
                    pred_var_key = 'cd'
                else:
                    raise NotImplementedError("only pressure velocity works")
                return {pred_var_key:pred_var}
        
            def loss_dict(self, data_dict, loss_fn=None, **kwargs):
                input_grid_features, output_points = self.data_dict_to_input(data_dict)
                # print(input_grid_features.shape,output_points.shape)
                pred_var = self(input_grid_features, output_points)
                # print(pred_var.shape)
                # print("-----------------------")
        
                true_var = None
                if 'pressure' in data_dict.keys():
                    true_var = data_dict['pressure'].unsqueeze(-1)
                elif "velocity" in data_dict.keys():
                    true_var =  data_dict['velocity']
                elif "cd" in data_dict.keys():
                    # pred_var =  paddle.mean(pred_var)
                    true_var =  data_dict['cd']
                else:
                    raise NotImplementedError("only pressure velocity works")
                # print("pred_var = ", pred_var)
                # print("true_var = ", true_var)
                return {'loss': loss_fn(pred_var, true_var)}
        model = My_RegDGCNN()
    else:
        raise ValueError("Network not supported")

    print("The model size is ", count_params(model))
    return model
